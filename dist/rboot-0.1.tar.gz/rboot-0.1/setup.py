from setuptools import setup

setup(name='rboot',
      version='0.01',
      description='Replacment Bootstrap',
      url='http://www.amirsani.com',
      author='Amir Sani',
      author_email='reachme@amirsani.com',
      download_url='https://github.com/amirsani/rboot_python',
      packages=['rboot'],
      zip_safe=False)
